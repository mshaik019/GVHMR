from .src.vitpose_infer.model_builder import build_model
